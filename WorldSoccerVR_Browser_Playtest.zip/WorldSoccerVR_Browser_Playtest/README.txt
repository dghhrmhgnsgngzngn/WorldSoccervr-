WORLD SOCCER VR — BROWSER SOLO PROTOTYPE

This is an experimental browser playtest, not the finished game.

To publish privately:
1. Create a free static site on a HTTPS hosting provider such as Netlify Drop or Cloudflare Pages.
2. Upload the index.html file.
3. Keep the URL unlisted and share it only with invited testers. Note: unlisted URL is not password protection; anyone with the link can access it.
4. Open the resulting HTTPS URL in Meta Quest Browser and choose Enter VR.

The prototype requires internet access for the Three.js CDN. The headset browser must support immersive-vr WebXR. Browser grip button indices and thumbstick axes can vary; test controls on your headset. No multiplayer, account system, secure invite gate, or finished character creator exists in this prototype. It has not been tested on a headset.
