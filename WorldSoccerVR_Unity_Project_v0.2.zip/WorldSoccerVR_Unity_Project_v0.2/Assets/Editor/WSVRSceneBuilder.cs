using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;
using UnityEngine.XR;

public static class WSVRSceneBuilder
{
    [MenuItem("World Soccer VR/Create Training Arena")]
    public static void CreateTrainingArena()
    {
        if (!EditorUtility.DisplayDialog("Create training arena?", "This creates a NEW scene. Save any current scene first.", "Create", "Cancel")) return;
        EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.name = "Small Arena - Turf";
        ground.transform.position = new Vector3(0, -0.15f, 0);
        ground.transform.localScale = new Vector3(25, 0.3f, 40);
        ground.GetComponent<Renderer>().sharedMaterial = MakeMaterial("Turf", new Color(.10f,.38f,.18f));
        CreateLine(new Vector3(-12.3f,.015f,0), new Vector3(-12.3f,.015f,40), .12f);
        CreateLine(new Vector3(12.3f,.015f,0), new Vector3(12.3f,.015f,40), .12f);
        CreateLine(new Vector3(0,.015f,-19.6f), new Vector3(25,.015f,-19.6f), .12f, true);
        CreateLine(new Vector3(0,.015f,19.6f), new Vector3(25,.015f,19.6f), .12f, true);
        CreateLine(new Vector3(-12.3f,.015f,0), new Vector3(12.3f,.015f,0), .10f);
        MakeGoal(-19.5f, "Blue"); MakeGoal(19.5f, "Red");

        GameObject ballObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        ballObj.name = "Soccer Ball";
        ballObj.transform.position = new Vector3(0,.35f,0);
        ballObj.transform.localScale = Vector3.one * .22f;
        ballObj.GetComponent<Renderer>().sharedMaterial = MakeMaterial("Soccer Ball White", Color.white);
        ballObj.AddComponent<Rigidbody>();
        WSVRBall ball = ballObj.AddComponent<WSVRBall>();

        GameObject rig = new GameObject("Player Rig - XR Tracking Origin");
        rig.transform.position = new Vector3(0,0,-5);
        CharacterController capsule = rig.AddComponent<CharacterController>();
        capsule.radius = .3f; capsule.height = 1.7f; capsule.center = new Vector3(0,.85f,0);
        WSVRMovement movement = rig.AddComponent<WSVRMovement>();
        GameObject head = new GameObject("Headset (XR tracked)");
        head.transform.SetParent(rig.transform, false);
        head.transform.localPosition = new Vector3(0,1.65f,0);
        head.tag = "MainCamera";
        head.AddComponent<Camera>(); head.AddComponent<AudioListener>();
        // Tracking pose requires XR provider + tracking component added in Unity.
        movement.headset = head.transform;
        MakeHand(rig.transform, XRNode.LeftHand, "Left", new Vector3(-.25f,1.2f,.4f));
        MakeHand(rig.transform, XRNode.RightHand, "Right", new Vector3(.25f,1.2f,.4f));
        WSVRTrainingReset reset = rig.AddComponent<WSVRTrainingReset>(); reset.ball = ball; reset.spawnPosition = new Vector3(0,.35f,0);

        EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
        EditorSceneManager.SaveScene(SceneManager.GetActiveScene(), "Assets/WorldSoccerVR_Training.unity");
        EditorUtility.DisplayDialog("Arena created", "Training scene saved to Assets/WorldSoccerVR_Training.unity. Configure XR headset tracking and OpenXR before building for Quest. See README.", "OK");
    }
    static Material MakeMaterial(string name, Color color)
    {
        Material m = new Material(Shader.Find("Standard")); m.name = name; m.color = color;
        return m;
    }
    static void CreateLine(Vector3 a, Vector3 b, float width, bool horizontal = false)
    {
        // a/b are endpoints in world coordinates.
        GameObject line = GameObject.CreatePrimitive(PrimitiveType.Cube);
        line.name = "Field Line"; line.transform.position = (a+b)*.5f;
        line.transform.localScale = new Vector3(width,.025f,Vector3.Distance(a,b));
        line.transform.rotation = Quaternion.LookRotation((b-a).normalized, Vector3.up);
        line.GetComponent<Renderer>().sharedMaterial = MakeMaterial("White Line",Color.white);
    }
    static void MakeGoal(float z, string team)
    {
        GameObject group = new GameObject(team + " Goal");
        foreach (Vector3 pos in new [] {new Vector3(-1.5f,1,z), new Vector3(1.5f,1,z)})
        {
            GameObject post = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            post.name="Post"; post.transform.SetParent(group.transform);
            post.transform.position=pos; post.transform.localScale=new Vector3(.07f,1,.07f);
        }
        GameObject bar=GameObject.CreatePrimitive(PrimitiveType.Cube); bar.name="Crossbar";
        bar.transform.SetParent(group.transform); bar.transform.position=new Vector3(0,2,z);
        bar.transform.localScale=new Vector3(3,.08f,.08f);
        GameObject trigger=new GameObject("Goal Detection"); trigger.transform.SetParent(group.transform);
        trigger.transform.position=new Vector3(0,1,z); BoxCollider c=trigger.AddComponent<BoxCollider>();
        c.size=new Vector3(2.9f,1.9f,.35f); c.isTrigger=true;
        trigger.AddComponent<WSVRGoalTrigger>().scoringTeam=team;
    }
    static void MakeHand(Transform parent, XRNode node, string label, Vector3 initial)
    {
        GameObject hand=GameObject.CreatePrimitive(PrimitiveType.Sphere);
        hand.name=label+" Hand - Controller Tracked";
        hand.transform.SetParent(parent,false); hand.transform.localPosition=initial;
        hand.transform.localScale=Vector3.one*.12f;
        Object.DestroyImmediate(hand.GetComponent<SphereCollider>());
        WSVRTrackedController tracker=hand.AddComponent<WSVRTrackedController>();
        tracker.hand=node; tracker.trackingOrigin=parent;
        SphereCollider kick=hand.AddComponent<SphereCollider>(); kick.radius=.65f; kick.isTrigger=true;
        hand.AddComponent<WSVRFootKick>();
        // Separate trigger is used so catching and kicking don't share a collider.
        GameObject catchProxy=new GameObject("Catch Proxy"); catchProxy.transform.SetParent(hand.transform,false);
        SphereCollider catch=catchProxy.AddComponent<SphereCollider>(); catch.radius=.75f; catch.isTrigger=true;
        WSVRGoalkeeperHands goalkeeper=catchProxy.AddComponent<WSVRGoalkeeperHands>();
        goalkeeper.hand=node; goalkeeper.ballHoldPoint=hand.transform;
        goalkeeper.insideOwnPenaltyArea=true; // TRAINING ONLY: must be validated before multiplayer.
    }
}
