using UnityEngine;

[RequireComponent(typeof(Rigidbody), typeof(SphereCollider))]
public class WSVRBall : MonoBehaviour
{
    public float maximumSpeed = 35f;
    public float kickMultiplier = 1.3f;
    public float minimumKickSpeed = 0.7f;
    public float kickCooldown = 0.12f;
    private Rigidbody body;
    private float lastKick = -100f;

    void Awake()
    {
        body = GetComponent<Rigidbody>();
        body.mass = 0.43f;
        body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        body.interpolation = RigidbodyInterpolation.Interpolate;
    }

    public void Kick(Vector3 direction, float controllerSpeed)
    {
        if (WSVRGoalkeeperHands.IsBallHeld || Time.time - lastKick < kickCooldown) return;
        if (controllerSpeed < minimumKickSpeed || direction.sqrMagnitude < 0.001f) return;
        lastKick = Time.time;
        body.AddForce(direction.normalized * controllerSpeed * kickMultiplier, ForceMode.Impulse);
        if (body.velocity.magnitude > maximumSpeed)
            body.velocity = body.velocity.normalized * maximumSpeed;
    }

    public Rigidbody Body => body;
}
