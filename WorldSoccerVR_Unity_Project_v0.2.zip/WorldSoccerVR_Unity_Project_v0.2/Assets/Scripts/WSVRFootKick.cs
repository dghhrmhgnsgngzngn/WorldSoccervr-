using UnityEngine;

// Attach to a small trigger collider on a tracked controller proxy.
// This is a starter controller-to-foot approximation, not finished foot IK.
[RequireComponent(typeof(Collider))]
public class WSVRFootKick : MonoBehaviour
{
    public float minimumSwingSpeed = 0.7f;
    private Vector3 previousPosition;
    private Vector3 velocity;

    void Start()
    {
        GetComponent<Collider>().isTrigger = true;
        previousPosition = transform.position;
    }

    void Update()
    {
        velocity = (transform.position - previousPosition) / Mathf.Max(Time.deltaTime, 0.001f);
        previousPosition = transform.position;
    }

    void OnTriggerStay(Collider other)
    {
        WSVRBall ball = other.GetComponent<WSVRBall>();
        if (ball == null || velocity.magnitude < minimumSwingSpeed) return;
        Vector3 direction = velocity.normalized;
        ball.Kick(direction, velocity.magnitude);
    }
}
