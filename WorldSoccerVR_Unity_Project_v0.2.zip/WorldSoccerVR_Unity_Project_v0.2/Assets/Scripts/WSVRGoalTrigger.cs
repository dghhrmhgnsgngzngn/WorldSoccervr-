using UnityEngine;

[RequireComponent(typeof(Collider))]
public class WSVRGoalTrigger : MonoBehaviour
{
    public string scoringTeam = "Blue";
    private float lastGoalTime = -100f;
    void Awake() { GetComponent<Collider>().isTrigger = true; }
    void OnTriggerEnter(Collider other)
    {
        WSVRBall ball = other.GetComponent<WSVRBall>();
        if (ball == null || Time.time - lastGoalTime < 2f) return;
        lastGoalTime = Time.time;
        Debug.Log("GOAL for " + scoringTeam + "! (training prototype)");
    }
}
