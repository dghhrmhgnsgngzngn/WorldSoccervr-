using UnityEngine;
using UnityEngine.XR;

// Prototype local-player goalkeeper interaction. Use on each tracked hand proxy.
[RequireComponent(typeof(Collider))]
public class WSVRGoalkeeperHands : MonoBehaviour
{
    public XRNode hand = XRNode.LeftHand;
    public Transform ballHoldPoint;
    public bool goalkeeperMode = true;
    public bool insideOwnPenaltyArea = true; // Replace with penalty-area trigger checks.
    public float maxCatchSpeed = 15f;
    private WSVRBall nearbyBall;
    private static WSVRBall heldBall;
    private static WSVRGoalkeeperHands holdingHand;
    private bool previouslyGripping;
    private Vector3 previousPosition;
    private Vector3 handVelocity;
    public static bool IsBallHeld => heldBall != null;

    void Start()
    {
        GetComponent<Collider>().isTrigger = true;
        previousPosition = transform.position;
    }

    void Update()
    {
        handVelocity = (transform.position - previousPosition) / Mathf.Max(Time.deltaTime, 0.001f);
        previousPosition = transform.position;
        InputDevice device = InputDevices.GetDeviceAtXRNode(hand);
        device.TryGetFeatureValue(CommonUsages.gripButton, out bool gripping);

        if (goalkeeperMode && insideOwnPenaltyArea && gripping && !previouslyGripping && heldBall == null && nearbyBall != null && nearbyBall.Body.velocity.magnitude <= maxCatchSpeed)
        {
            heldBall = nearbyBall;
            holdingHand = this;
            heldBall.Body.isKinematic = true;
            heldBall.Body.velocity = Vector3.zero;
        }

        if (heldBall != null && holdingHand == this)
        {
            if (!gripping || !insideOwnPenaltyArea)
            {
                WSVRBall released = heldBall;
                heldBall = null;
                holdingHand = null;
                released.Body.isKinematic = false;
                released.Body.velocity = handVelocity;
            }
            else
            {
                Transform point = ballHoldPoint != null ? ballHoldPoint : transform;
                heldBall.transform.position = point.position;
            }
        }
        previouslyGripping = gripping;
    }

    void OnTriggerEnter(Collider other)
    {
        WSVRBall ball = other.GetComponent<WSVRBall>();
        if (ball != null) nearbyBall = ball;
    }

    void OnTriggerExit(Collider other)
    {
        if (nearbyBall != null && other.gameObject == nearbyBall.gameObject) nearbyBall = null;
    }
}
