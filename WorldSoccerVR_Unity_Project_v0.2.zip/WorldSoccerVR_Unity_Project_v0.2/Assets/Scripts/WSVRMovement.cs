using UnityEngine;
using UnityEngine.XR;

[RequireComponent(typeof(CharacterController))]
public class WSVRMovement : MonoBehaviour
{
    public Transform headset;
    public float walkSpeed = 3.5f;
    public float sprintSpeed = 6.5f;
    public float turnSpeed = 90f;
    public float gravity = -9.81f;
    public float minimumHeight = 0.9f;
    public float maximumHeight = 2.1f;
    public float snapTurnDeadzone = 0.65f;
    public bool smoothTurn = false;

    private CharacterController controller;
    private float verticalVelocity;
    private bool canSnap = true;

    void Awake() { controller = GetComponent<CharacterController>(); }

    void Update()
    {
        if (headset == null) return;
        InputDevice left = InputDevices.GetDeviceAtXRNode(XRNode.LeftHand);
        InputDevice right = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
        left.TryGetFeatureValue(CommonUsages.primary2DAxis, out Vector2 movement);
        right.TryGetFeatureValue(CommonUsages.primary2DAxis, out Vector2 turning);
        left.TryGetFeatureValue(CommonUsages.gripButton, out bool leftGrip);

        // The left grip sprints unless a goalkeeper catch is actively holding the ball.
        bool carryingBall = WSVRGoalkeeperHands.IsBallHeld;
        float speed = leftGrip && !carryingBall ? sprintSpeed : walkSpeed;
        Vector3 forward = headset.forward;
        Vector3 sideways = headset.right;
        forward.y = 0f; sideways.y = 0f;
        forward.Normalize(); sideways.Normalize();
        Vector3 desired = Vector3.ClampMagnitude(forward * movement.y + sideways * movement.x, 1f);

        if (controller.isGrounded && verticalVelocity < 0f) verticalVelocity = -1f;
        else verticalVelocity += gravity * Time.deltaTime;
        controller.Move((desired * speed + Vector3.up * verticalVelocity) * Time.deltaTime);

        if (smoothTurn) transform.Rotate(0f, turning.x * turnSpeed * Time.deltaTime, 0f);
        else
        {
            if (Mathf.Abs(turning.x) < 0.3f) canSnap = true;
            if (canSnap && Mathf.Abs(turning.x) > snapTurnDeadzone)
            {
                transform.Rotate(0f, Mathf.Sign(turning.x) * 45f, 0f);
                canSnap = false;
            }
        }

        // Headset height changes the collision capsule; no crouch button.
        float height = Mathf.Clamp(headset.localPosition.y, minimumHeight, maximumHeight);
        controller.height = height;
        Vector3 center = headset.localPosition;
        center.y = height * 0.5f;
        controller.center = center;
    }
}
