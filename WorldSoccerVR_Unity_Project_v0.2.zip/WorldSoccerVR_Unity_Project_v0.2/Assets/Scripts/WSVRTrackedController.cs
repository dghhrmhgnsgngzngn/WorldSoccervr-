using UnityEngine;
using UnityEngine.XR;

// Reads tracked controller pose directly from XR input devices.
public class WSVRTrackedController : MonoBehaviour
{
    public XRNode hand = XRNode.LeftHand;
    public Transform trackingOrigin;
    void Update()
    {
        InputDevice device = InputDevices.GetDeviceAtXRNode(hand);
        if (!device.isValid) return;
        if (device.TryGetFeatureValue(CommonUsages.devicePosition, out Vector3 position))
            transform.position = trackingOrigin != null ? trackingOrigin.TransformPoint(position) : position;
        if (device.TryGetFeatureValue(CommonUsages.deviceRotation, out Quaternion rotation))
            transform.rotation = trackingOrigin != null ? trackingOrigin.rotation * rotation : rotation;
    }
}
