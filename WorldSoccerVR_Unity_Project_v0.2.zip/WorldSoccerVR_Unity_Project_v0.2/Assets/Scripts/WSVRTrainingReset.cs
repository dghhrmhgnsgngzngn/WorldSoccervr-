using UnityEngine;
using UnityEngine.XR;

// Press the right controller's primary button to reset the training ball.
public class WSVRTrainingReset : MonoBehaviour
{
    public WSVRBall ball;
    public Vector3 spawnPosition = new Vector3(0f, 0.2f, 0f);
    private bool wasPressed;
    void Update()
    {
        InputDevice device = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
        device.TryGetFeatureValue(CommonUsages.primaryButton, out bool pressed);
        if (pressed && !wasPressed && ball != null && !WSVRGoalkeeperHands.IsBallHeld)
        {
            ball.Body.velocity = Vector3.zero;
            ball.Body.angularVelocity = Vector3.zero;
            ball.transform.position = spawnPosition;
        }
        wasPressed = pressed;
    }
}
