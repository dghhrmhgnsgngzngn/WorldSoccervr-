# World Soccer VR — Unity project source v0.2

This is an **uncompiled Unity source project**, NOT a playable Quest APK. It was assembled without running the Unity Editor or testing on Quest. The Unity version/package combinations may need updating in Hub/Package Manager.

## What's included
- Source code for joystick movement, left-grip sprint, snap turning, and physical crouch capsule.
- Prototype controller-driven ball contact, local goalkeeper catch using either grip, training ball reset (right primary button), and basic goal detection.
- Unity Editor menu command **World Soccer VR > Create Training Arena** which creates and saves a basic 40 x 25 meter training field, two goals, a physics ball, player rig, and controller proxies.
- ProjectSettings/ProjectVersion.txt and Packages/manifest.json for a starting Unity project.

## Getting started (Windows)
1. Install Unity Hub and **Unity 2022.3 LTS** with Android Build Support (SDK/NDK and OpenJDK). If this exact version isn't available, use a supported LTS and let Unity migrate packages.
2. Extract this ZIP, then in Unity Hub choose **Add project from disk** and select the extracted `WorldSoccerVR_Unity_Project_v0.2` folder.
3. Open the project and let packages import. Fix any package-version prompts using Package Manager.
4. From the Unity top menu choose **World Soccer VR > Create Training Arena**. The scene is saved as `Assets/WorldSoccerVR_Training.unity`.
5. **XR SETUP REQUIRED:** In Project Settings > XR Plug-in Management, enable OpenXR for Android, add Quest-compatible interaction profiles and configure Quest runtime. Add a headset tracked-pose component to the Headset object, or replace the generated rig with an XR Origin and connect its camera and controller transforms to the scripts. The generated rig does not itself enable headset tracking.
6. In Player Settings, use Android target, ARM64, IL2CPP, and compatible input handling. Ensure XR device permissions, SDK versions, and graphics settings match your Quest/OpenXR package versions.
7. Add the training scene to Build Settings and build to your developer-enabled Meta Quest headset.

## Important known limitations
- No full body character, menu, saves, online multiplayer, matchmaking, or 11v11 yet.
- Ball contact uses controller proxies, not final virtual foot IK.
- Catch logic is local-only and allows a single holding hand; both grips can independently initiate a catch, but coordinated two-hand catches aren't implemented.
- `insideOwnPenaltyArea` is deliberately true for training. Competitive matches MUST check actual area boundaries and validate catches on the server.
- Generated arena is intentionally simple, and requires Quest tracking setup before testing.
- Controller-proxy trigger colliders may need tuning to prevent accidental kicks/catches. Physics tuning, OpenXR compatibility, and compile checks must be done in Unity.
- No jump/crouch buttons; real-life jumping is not required.

## Build order
1. Test headset tracking and movement.
2. Test kicks and goalkeeper grips.
3. Add proper procedural player legs and body IK.
4. Add private multiplayer and server-authoritative physics.
5. Add ranked, character creator, modes, and other planned features.
